// minden gomb itt helyezkedik el
var btn = document.querySelectorAll(".btn");

// az összeg számolásához szükséeges változók
var player_score_count = 0;
var cpu_score_count = 0;

// a gombok medósusának összegyűjtését itt történik meg
Array.from(btn).forEach((e) => {
  // a gombok click rendszerét ide helyeztük el
  e.addEventListener("click", (e) => {
    document.querySelector(".player-1").innerHTML = e.target.getAttribute(
      "data-value"
    );
    // random számok generálása
    var num = Math.floor(Math.random() * 3);
    // a cpu válaszát generálja
    if (num == 0) 
	{
      document.querySelector(".cpu").innerHTML = "✊";
    }
    if (num == 1) 
	{
      document.querySelector(".cpu").innerHTML = "✋";
    }
    if (num == 2) 
	{
      document.querySelector(".cpu").innerHTML = "✌";
    }
    // az igaz hamis rész megírása található itt
    if 
	(
      document.querySelector(".player-1").innerHTML == "✊" &&
      document.querySelector(".cpu").innerHTML == "✌"
    ) 
	{
      cpu_score_count = cpu_score_count + 1;
      document.querySelector(".cpu-score").innerHTML = cpu_score_count;
    }
    if 
	(
      document.querySelector(".player-1").innerHTML == "✌" &&
      document.querySelector(".cpu").innerHTML == "✊"
    ) 
	{
      player_score_count = player_score_count + 1;
      document.querySelector(".player-score").innerHTML = player_score_count;
    }
    if 
	(
      document.querySelector(".player-1").innerHTML == "✊" &&
      document.querySelector(".cpu").innerHTML == "✋"
    ) 
	{
      cpu_score_count = cpu_score_count + 1;
      document.querySelector(".cpu-score").innerHTML = cpu_score_count;
    }
    if 
	(
      document.querySelector(".player-1").innerHTML == "✋" &&
      document.querySelector(".cpu").innerHTML == "✊"
    ) 
	{
      player_score_count = player_score_count + 1;
      document.querySelector(".player-score").innerHTML = player_score_count;
    }
    if 
	(
      document.querySelector(".player-1").innerHTML == "✋" &&
      document.querySelector(".cpu").innerHTML == "✌"
    ) 
	{
      cpu_score_count = cpu_score_count + 1;
      document.querySelector(".cpu-score").innerHTML = cpu_score_count;
    }
    if 
	(
      document.querySelector(".player-1").innerHTML == "✌" &&
      document.querySelector(".cpu").innerHTML == "✋"
    ) 
	{
      player_score_count = player_score_count + 1;
      document.querySelector(".player-score").innerHTML = player_score_count;
    }
    if 
	(
      document.querySelector(".player-1").innerHTML ==
      document.querySelector(".cpu").innerHTML
    ) 
	{
      alert("Döntetlen");
    }
  });
});

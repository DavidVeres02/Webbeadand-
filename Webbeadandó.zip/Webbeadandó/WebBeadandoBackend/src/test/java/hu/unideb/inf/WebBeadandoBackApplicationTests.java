package hu.unideb.inf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBeadandoBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
